﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DailyBasket.Models
{
    public class Order
    {
        public int Id { get; set; }

        public DateTime OrderDate { get; set; } = DateTime.Now;

        // Customer Info
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }

        // Address
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string ZipCode { get; set; }
        public string Province { get; set; } = "Ontario";

        // Payment Info (last 4 digits for security)
        public string CardLast4Digits { get; set; }

        public decimal Total { get; set; }
        public decimal Tax { get; set; }
        public decimal Subtotal { get; set; }

        public List<OrderItem> Items { get; set; }
    }
}
