﻿using Microsoft.EntityFrameworkCore;

namespace DailyBasket.Models
{
    public class DailyBasketContext : DbContext
    {
        public DailyBasketContext(DbContextOptions<DailyBasketContext> options) : base(options) { }

        public DbSet<Product> Products { get; set; }
        public DbSet<User> Users { get; set; }  // If not using Identity
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }

    }
}
