﻿using System.ComponentModel.DataAnnotations;

namespace DailyBasket.Models
{
    public class CheckoutViewModel
    {
        // Customer Info
        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        // Address
        [Required]
        public string AddressLine1 { get; set; }

        public string AddressLine2 { get; set; }

        [Required]
        public string City { get; set; }

        [Required, RegularExpression(@"^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$", ErrorMessage = "Enter a valid Canadian postal code.")]
        public string ZipCode { get; set; }

        public string Province => "Ontario";

        // Payment
        [Required, RegularExpression(@"^\d{16}$", ErrorMessage = "Card number must be 16 digits.")]
        public string CardNumber { get; set; }

        [Required, RegularExpression(@"^\d{3}$", ErrorMessage = "CVV must be 3 digits.")]
        [DataType(DataType.Password)]
        public string CVV { get; set; }

        [Required]
        public int ExpiryMonth { get; set; }

        [Required]
        public int ExpiryYear { get; set; }

        // Cart values
        public decimal Total { get; set; }
        public decimal Tax => Total * 0.13M;
        public decimal Subtotal => Total + Tax;
    }
}
