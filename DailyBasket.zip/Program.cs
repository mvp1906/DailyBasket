﻿using Microsoft.EntityFrameworkCore;
using DailyBasket.Models;

var builder = WebApplication.CreateBuilder(args);

// Register services
builder.Services.AddControllersWithViews();
builder.Services.AddSession();
builder.Services.AddHttpContextAccessor();

builder.Services.AddDbContext<DailyBasketContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DailyBasketConnection")));

var app = builder.Build();

// Seed default admin user if not exists
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<DailyBasketContext>();
    db.Database.Migrate(); // apply pending migrations

    if (!db.Users.Any(u => u.Email == "admin@dailybasket.com"))
    {
        db.Users.Add(new User
        {
            Email = "admin@dailybasket.com",
            Password = "admin", // NOTE: For real projects, hash the password
            Role = "Admin"
        });
        db.SaveChanges();
    }
}

// Configure middleware
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseSession(); // enable session before routing
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
