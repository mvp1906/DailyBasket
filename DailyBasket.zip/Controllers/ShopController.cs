﻿using DailyBasket.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DailyBasket.Controllers
{
    public class ShopController : Controller
    {
        private readonly DailyBasketContext _context;

        public ShopController(DailyBasketContext context)
        {
            _context = context;
        }

        // GET: /Shop
        public async Task<IActionResult> Index()
        {
            var products = await _context.Products.ToListAsync();
            return View(products);
        }
    }
}
