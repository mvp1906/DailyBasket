﻿using DailyBasket.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;


namespace DailyBasket.Controllers
{
    public class CheckoutController : Controller
    {
        private readonly DailyBasketContext _context;
        public CheckoutController(DailyBasketContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Checkout()
        {
            var cart = HttpContext.Session.GetString("Cart");
            var cartItems = string.IsNullOrEmpty(cart) ? new List<CartItem>() : System.Text.Json.JsonSerializer.Deserialize<List<CartItem>>(cart);
            var total = cartItems.Sum(c => c.Price * c.Quantity);

            var model = new CheckoutViewModel
            {
                Total = total
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SubmitCheckout(CheckoutViewModel model)
        {
            var cartJson = HttpContext.Session.GetString("Cart");
            var cart = string.IsNullOrEmpty(cartJson) ? new List<CartItem>() : JsonSerializer.Deserialize<List<CartItem>>(cartJson);
            model.Total = cart.Sum(c => c.Price * c.Quantity);

            var expiry = new DateTime(model.ExpiryYear, model.ExpiryMonth, 1);
            if (expiry < new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1))
            {
                ModelState.AddModelError("ExpiryYear", "Expiry date must be in the future.");
            }

            if (!ModelState.IsValid)
            {
                return View("Checkout", model);
            }

            // Save order
            var order = new Order
            {
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                AddressLine1 = model.AddressLine1,
                AddressLine2 = model.AddressLine2,
                City = model.City,
                ZipCode = model.ZipCode,
                CardLast4Digits = model.CardNumber.Substring(model.CardNumber.Length - 4),
                Total = model.Total,
                Tax = model.Tax,
                Subtotal = model.Subtotal,
                Items = cart.Select(c => new OrderItem
                {
                    ProductId = c.ProductId,
                    ProductName = c.Name,
                    UnitPrice = c.Price,
                    Quantity = c.Quantity
                }).ToList()
            };

            _context.Orders.Add(order);
            _context.SaveChanges(); // Saves and generates Order.Id

            // Clear cart session
            HttpContext.Session.Remove("Cart");

            // Redirect to thank you page with order ID
            return RedirectToAction("ThankYou", new { id = order.Id });
        }



        public IActionResult ThankYou(int id)
        {
            var order = _context.Orders
                .Include(o => o.Items)
                .FirstOrDefault(o => o.Id == id);

            if (order == null)
            {
                return NotFound();
            }

            return View(order);
        }

    }
}
