﻿using DailyBasket.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DailyBasket.Controllers
{
    public class OrdersController : Controller
    {
        private readonly DailyBasketContext _context;

        public OrdersController(DailyBasketContext context)
        {
            _context = context;
        }

        // GET: /Orders
        public IActionResult Index()
        {
            var orders = _context.Orders
                .Include(o => o.Items)
                .OrderByDescending(o => o.OrderDate)
                .ToList();

            return View(orders);
        }

        // GET: /Orders/Details/5
        public IActionResult Details(int id)
        {
            var order = _context.Orders
                .Include(o => o.Items)
                .FirstOrDefault(o => o.Id == id);

            if (order == null)
                return NotFound();

            return View(order);
        }
    }
}
